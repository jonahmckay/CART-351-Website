<?php
 require('openDB.php');

 try{
$theQuery = "CREATE TABLE users (userID INTEGER PRIMARY KEY NOT NULL, username TEXT, password TEXT)";
$file_db ->exec($theQuery);
echo ("Table users created successfully<br>");
$file_db = null;
}
catch(PDOException $e) {
    // Print PDOException message
    echo $e->getMessage();
  }
?>
