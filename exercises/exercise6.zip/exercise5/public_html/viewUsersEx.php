

<html>

  <head>
    <link rel="stylesheet" href="style.css">
  </head>

  <body>
    <h3>Registered users</h3>
    <div id="tableDiv">
    <table id="usersTable">
      <tr>
      <td>
      User Name
      </td>
      <td>
      Password
      </td>
    </tr>
    <?php
      require('openDB.php');

      $query = 'SELECT * FROM users';
      try
      {
          $result = $file_db->query($query);
      }
      catch (PDOException $e)
      {
        die("query failed, table likely does not exist. Try opening createExerciseDb.php to create the table");
      }



      while($row = $result->fetch(PDO::FETCH_ASSOC))
      {
        echo "<tr>";
        echo "<td>";
        echo $row["username"];
        echo "</td>";
        echo "<td>";
        echo $row["password"];
        echo "</td>";
        echo "</tr>";
      }
      ?>
    </table>
  </div>
  </body>

</html>
