<?php

  if($_SERVER['REQUEST_METHOD'] == 'POST')
  {
    require('openDB.php');
    $username = $_POST['u_name'];
    $password = $_POST['u_password'];

    $query = "SELECT COUNT(*) as count FROM users WHERE lower(username) = lower('$username')";

    try
    {
      $result = $file_db->prepare($query);
    }
    catch (PDOException $e)
    {
      die("query failed, table likely does not exist. Try opening createExerciseDb.php to create the table");
    }
    $result->execute();

    $rowCount = $result->fetchColumn();

    echo $rowCount;
    $resultMessage = "default result message";

    if ($rowCount < 1)
    {
      //insert new user into database
      $insertQuery = "INSERT INTO users (username, password) VALUES ('$username', '$password')";
      $file_db->exec($insertQuery);

      $resultMessage = "User added successfully";
    }
    else
    {
      $resultMessage = "User already exists";
    }
  }
?>

<html>

  <head>
    <script>
      resultMessage = "<?php echo $resultMessage ?: "no message" ?>";
      alert(resultMessage);
    </script>

    <link rel="stylesheet" href="style.css">
  </head>

  <body>
    <form id="insertUser" method="post">
    <h3>Registration form</h3>
    <h4>Note: insecure webpage! Do not enter sensitive information here</h3>
    <fieldset>
      <p><label>User Name: </label><input class="textInput" type="text" size="24" maxlength = "40" name = "u_name" required></p>
      <p><label> Password: </label><input class="textInput" type = "text" size="24" maxlength = "40"  name = "u_password" required></p>
      <p class = "sub"><input class="buttonInput" type = "submit" name = "submit" value = "Register" id ="buttonS" /></p>
    </fieldset>
    </form>
  </body>

</html>
